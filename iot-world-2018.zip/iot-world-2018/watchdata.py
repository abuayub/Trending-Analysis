#!/usr/bin/env python

import requests
import random

res = requests.get('http://0.0.0.0:3306/watchdata/' + str(random.randint(120, 160)))
if res.ok:
    print(res.text)
