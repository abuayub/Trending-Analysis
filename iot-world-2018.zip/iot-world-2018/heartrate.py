#!/usr/bin/env python

import requests
import random

res = requests.get('http://0.0.0.0:3306/heartrate/')
if res.ok:
    print(res.text)
    print("Done !!")
