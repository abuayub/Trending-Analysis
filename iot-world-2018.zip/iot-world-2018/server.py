#!/usr/bin/env python

from flask import Flask, request, jsonify, session, render_template
from flask.ext.socketio import SocketIO, emit
from flask_socketio import SocketIO
from datetime import datetime
import redis

#############
# VARIABLES #
#############
app = Flask(__name__)
app.secret_key = 'A0Zr98j/XHH!jmN]LWX/,?RT'
viewName = redis.StrictRedis(host='0.0.0.0', port=6379, db=0)
viewName.set('view', 'index')
socketio = SocketIO(app)

#########
# VIEWS #
#########

@app.route('/')
def index():
    print(viewName.get('view').decode('utf-8'))
    if viewName.get('view').decode('utf-8') == 'charts':
        return render_template('charts.html', viewName=viewName.get('view').decode('utf-8'))
    elif viewName.get('view').decode('utf-8') == 'simulation':
        return render_template('simulation.html', viewName=viewName.get('view').decode('utf-8'))
    else:
        return render_template('index.html', viewName=viewName.get('view').decode('utf-8'))

@app.route('/simulation')
def simulation():
    return render_template('simulation.html')

@app.route('/charts')
def charts():
    return render_template('charts.html')

@app.route('/control')
def control():
    return render_template('control.html')

# @socketio.on('message')
# def handle_message(message):
#     print('received message: ' + message)
#     return 'message received'

@socketio.on('value changed')
def value_changed(message):
    print('Message received from client')
    print(message)
    #emit('view_name', viewName.get('view').decode('utf-8'), broadcast=True)
    send(viewName.get('view').decode('utf-8'), broadcast=True)
    print('view sent to client')

# @socketio.on('connect')
# def connect():
#     print('[*] Client connected')
#     emit('view_name', viewName.get('view').decode('utf-8'), broadcast=True)
#     print('[*] Server connected to client')

########
# APIs #
########

@app.route('/watchdata/<heartrate>', methods=['GET'])
def watchdata(heartrate):
    session['currentHeartRate'] = str(heartrate)
    session['currentTimeStamp'] = str(datetime.now())
    session.modified = True
    print(session['currentHeartRate'] + ' | ' + session['currentTimeStamp'])
    print(session)
    print("Data Posted")
    return 'Data posted in server..!'

@app.route('/heartrate/', methods=['GET','POST'])
def heartrate():
    print("get request")
    print(session)
    return str(session['currentHeartRate'])

    #+ ' ' + session['currentTimeStamp']
    #return "simple"

@app.route('/static/<path:path>', methods=['GET','POST'])
def static_files(path):
    return send_from_directory('static',path)

@app.route('/screenset/<view>', methods=['GET', 'POST'])
def screenset(view):
    viewName.set('view', view)
    print("[*] Upcoming view: " + viewName.get('view').decode('utf-8'))
    return viewName.get('view').decode('utf-8')

# @app.route('/switching', methods=['GET', 'POST'])
# def switching():
#     if viewName.get('view').decode('utf-8') == 'charts':
#         render_template('charts.html')
#     elif viewName.get('view').decode('utf-8') == 'simulation':
#         render_template('simulation.html')
#     else:
#         render_template('index.html')

if __name__ == '__main__':
    app.debug = True
    # app.host = '0.0.0.0'
    # app.port = 3306
    socketio.run(app)
